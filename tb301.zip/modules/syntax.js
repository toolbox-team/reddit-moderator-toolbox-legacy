function syntax() {

// syntax highlighter with ACE, by creesch

var syntax = new TB.Module('Syntax Highlighter');
syntax.shortname = 'Syntax';

syntax.settings['enabled']['default'] = true;

syntax.register_setting('enableWordWrap', {
    'type': 'boolean',
    'default': true,
    'title': 'Enable word wrap in editor'
});
syntax.register_setting('selectedTheme', {
    'type': 'syntaxTheme',
    'default': 'monokai',
    'title': 'Syntax highlight theme selection'
});

syntax.settings['enabled']['default'] = true; // on by default

// we reference this from tbobject for settings generation
syntax.themeSelect = '\
<select id="theme_selector">\
<option value="ambiance">ambiance</option>\
<option value="chaos">chaos</option>\
<option value="chrome">chrome</option>\
<option value="cloud9_day">cloud9_day</option>\
<option value="cloud9_night">cloud9_night</option>\
<option value="cloud9_night_low_color">cloud9_night_low_color</option>\
<option value="clouds">clouds</option>\
<option value="clouds_midnight">clouds_midnight</option>\
<option value="cobalt">cobalt</option>\
<option value="crimson_editor">crimson_editor</option>\
<option value="dawn">dawn</option>\
<option value="dreamweaver">dreamweaver</option>\
<option value="eclipse">eclipse</option>\
<option value="github">github</option>\
<option value="idle_fingers">idle_fingers</option>\
<option value="katzenmilch">katzenmilch</option>\
<option value="kuroir">kuroir</option>\
<option value="merbivore">merbivore</option>\
<option value="merbivore_soft">merbivore_soft</option>\
<option value="monokai">monokai</option>\
<option value="mono_industrial">mono_industrial</option>\
<option value="pastel_on_dark">pastel_on_dark</option>\
<option value="solarized_dark">solarized_dark</option>\
<option value="solarized_light">solarized_light</option>\
<option value="terminal">terminal</option>\
<option value="textmate">textmate</option>\
<option value="tomorrow">tomorrow</option>\
<option value="tomorrow_night">tomorrow_night</option>\
<option value="tomorrow_night_blue">tomorrow_night_blue</option>\
<option value="tomorrow_night_bright">tomorrow_night_bright</option>\
<option value="tomorrow_night_eighties">tomorrow_night_eighties</option>\
<option value="twilight">twilight</option>\
<option value="vibrant_ink">vibrant_ink</option>\
<option value="xcode">xcode</option>\
</select>\
';

syntax.init = function init() {
    var selectedTheme = this.setting('selectedTheme'),
        enableWordWrap = this.setting('enableWordWrap');

    if (location.pathname.match(/\/about\/stylesheet\/?/)) {
        $('.sheets .col').prepend('<div id="stylesheet_contents_div"></div>');

        var editor = ace.edit("stylesheet_contents_div"),
            session = editor.getSession(),
            textarea = $('textarea[name="stylesheet_contents"]').hide();

        editor.getSession().setUseWrapMode(enableWordWrap);

        editor.setTheme("ace/theme/" + selectedTheme);
        if (TBUtils.browser == 'chrome') {
            ace.config.set("workerPath", chrome.extension.getURL("/libs/"));
        } else if (TBUtils.browser == 'safari') {
            ace.config.set('workerPath', safari.extension.baseURI+'/libs/')
        } else if (TBUtils.browser == 'firefox') {
            session.setUseWorker(false);
        }
        session.setMode("ace/mode/css");

        session.setValue(textarea.val());
        session.on('change', function () {
            textarea.val(session.getValue());
        });

        var $body = $('body');
        $body.addClass('mod-toolbox-ace');

        $('#stylesheet_contents_div').before(this.themeSelect);

        $('#theme_selector').val(selectedTheme);

        $body.on('change keydown', '#theme_selector', function () {
            var thingy = $(this);
            setTimeout(function () {
                editor.setTheme("ace/theme/" + thingy.val());
            }, 0);
        });
    }

    if (location.pathname.match(/\/wiki\/edit\/automoderator\/?$/)
        || location.pathname.match(/\/wiki\/edit\/toolbox\/?$/)
    ) {
        var $body = $('body');
        var $editform = $('#editform');

        $editform.prepend('<div id="wiki_contents_div"></div>');

        var editor = ace.edit("wiki_contents_div"),
            session = editor.getSession(),
            textarea = $('textarea[name="content"]').hide();
        if (enableWordWrap) {
            editor.getSession().setUseWrapMode(true);
        }
        editor.setTheme("ace/theme/" + selectedTheme);

        if (location.pathname.match(/\/wiki\/edit\/automoderator\/?$/)) {
            session.setMode("ace/mode/yaml");
        }
        if (location.pathname.match(/\/wiki\/edit\/toolbox\/?$/)) {
            session.setMode("ace/mode/json");
        }
        session.setValue(textarea.val());
        session.on('change', function () {
            textarea.val(session.getValue());
        });
        $body.addClass('mod-toolbox-ace');

        $editform.prepend(this.themeSelect);

        $('#theme_selector').val(selectedTheme);

        $body.on('change keydown', '#theme_selector', function () {
            var thingy = $(this);
            setTimeout(function () {
                editor.setTheme("ace/theme/" + thingy.val());
            }, 0);
        });
    }

    $('.ace_editor').on("webkitTransitionEnd transitionend oTransitionEnd", function () {
        editor.resize();
    });

};

TB.register_module(syntax);
}

(function () {
    window.addEventListener("TBObjectLoaded", function () {
        syntax();
    });
})();
